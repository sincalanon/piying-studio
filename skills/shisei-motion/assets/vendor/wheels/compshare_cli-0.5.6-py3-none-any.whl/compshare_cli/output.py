from __future__ import annotations

import json
import sys
from datetime import datetime
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from compshare_cli.i18n import tr

SENSITIVE_KEYS = {
    "authorization",
    "command",
    "cookie",
    "eip",
    "filebrowserpassword",
    "hostip",
    "ip",
    "ipaddress",
    "ipaddr",
    "ipv4",
    "ipv6",
    "logincommand",
    "password",
    "privateip",
    "privatekey",
    "publicip",
    "secret",
    "secretkey",
    "ssh",
    "sshcommand",
    "sshlogincommand",
    "token",
    "url",
}

JSON_SCHEMA_VERSION = "1"
_TRANSPORT_KEYS = {"Action", "RetCode", "request_uuid"}


def _normalized_key(key: Any) -> str:
    return "".join(character for character in str(key).casefold() if character.isalnum())


def _is_sensitive_key(key: Any) -> bool:
    normalized = _normalized_key(key)
    return (
        normalized in SENSITIVE_KEYS
        or normalized.endswith("password")
        or normalized.endswith("secret")
        or normalized.endswith("token")
        or normalized.endswith("url")
    )


def sanitized(value: Any, *, show_sensitive: bool = False) -> Any:
    if show_sensitive:
        return value
    if isinstance(value, dict):
        return {
            key: "***" if _is_sensitive_key(key) else sanitized(item) for key, item in value.items()
        }
    if isinstance(value, list):
        return [sanitized(item) for item in value]
    return value


def _sanitized_with_paths(
    value: Any,
    *,
    show_sensitive: bool,
    path: str,
) -> Tuple[Any, List[str]]:
    if show_sensitive:
        return value, []
    if isinstance(value, dict):
        result: Dict[Any, Any] = {}
        redacted: List[str] = []
        for key, item in value.items():
            item_path = f"{path}.{key}"
            if _is_sensitive_key(key):
                result[key] = "***"
                redacted.append(item_path)
            else:
                result[key], item_redacted = _sanitized_with_paths(
                    item,
                    show_sensitive=False,
                    path=item_path,
                )
                redacted.extend(item_redacted)
        return result, redacted
    if isinstance(value, list):
        result = []
        redacted = []
        for index, item in enumerate(value):
            safe_item, item_redacted = _sanitized_with_paths(
                item,
                show_sensitive=False,
                path=f"{path}[{index}]",
            )
            result.append(safe_item)
            redacted.extend(item_redacted)
        return result, redacted
    return value, []


def _response_data(response: Mapping[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    data = {key: value for key, value in response.items() if key not in _TRANSPORT_KEYS}
    metadata: Dict[str, Any] = {}
    if response.get("Action") is not None:
        metadata["action"] = response["Action"]
    if response.get("RetCode") is not None:
        metadata["ret_code"] = response["RetCode"]
    if response.get("request_uuid") is not None:
        metadata["request_uuid"] = response["request_uuid"]
    return data, metadata


def _pagination_metadata(response: Mapping[str, Any]) -> Dict[str, Any]:
    mapping = {
        "TotalCount": "total",
        "FilteredCount": "filtered",
        "ReturnedCount": "returned",
        "Offset": "offset",
    }
    metadata = {
        target: response[source]
        for source, target in mapping.items()
        if response.get(source) is not None
    }
    if "Limit" in response:
        if response["Limit"] is None:
            metadata["all"] = True
        else:
            metadata["limit"] = response["Limit"]
    if response.get("RegionSet") is not None:
        metadata["regions"] = response["RegionSet"]
    return metadata


def _project_rows(
    rows: Iterable[Dict[str, Any]],
    fields: Sequence[str],
) -> List[Dict[str, Any]]:
    return [{field: row.get(field) for field in fields} for row in rows]


def _write_json(payload: Dict[str, Any]) -> None:
    """Write one UTF-8 JSON document independently of the console code page."""
    # PowerShell can decode native pipes using a legacy Windows console code page.
    document = (
        json.dumps(payload, ensure_ascii=sys.platform == "win32", separators=(",", ":")) + "\n"
    )
    stream = sys.stdout
    binary = getattr(stream, "buffer", None)
    if binary is not None:
        stream.flush()
        binary.write(document.encode("utf-8"))
        binary.flush()
        return
    # String-only test/application streams have no byte encoding contract. Escaping
    # non-ASCII keeps this fallback valid UTF-8 under every ASCII-compatible encoding.
    stream.write(json.dumps(payload, ensure_ascii=True, separators=(",", ":")) + "\n")
    stream.flush()


class Renderer:
    def __init__(self, json_output: bool, show_sensitive: bool = False) -> None:
        self.json_output = json_output
        self.show_sensitive = show_sensitive
        self.console = Console()

    def data(
        self,
        response: Dict[str, Any],
        *,
        rows: Optional[Iterable[Dict[str, Any]]] = None,
        columns: Optional[Sequence[Tuple[str, str]]] = None,
        json_list: bool = False,
        json_fields: Optional[Sequence[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        if self.json_output:
            if response.get("ok") is False:
                self._response_error(response)
                return
            data, response_metadata = _response_data(response)
            data.pop("ok", None)
            if data.get("error") is None:
                data.pop("error", None)
            if json_list:
                fields = tuple(json_fields or (key for key, _ in columns or ()))
                items = _project_rows(rows or (), fields)
                data = {"items": items}
                response_metadata.update(_pagination_metadata(response))
                response_metadata.setdefault("returned", len(items))
            if metadata:
                response_metadata.update(metadata)
            self._write_success(data, response_metadata)
            return
        safe = sanitized(response, show_sensitive=self.show_sensitive)
        if rows is not None and columns:
            self.table(rows, columns)
            return
        self.console.print_json(json.dumps(safe, ensure_ascii=False, default=str))

    def table(
        self,
        rows: Optional[Iterable[Dict[str, Any]]],
        columns: Sequence[Tuple[str, str]],
    ) -> None:
        table = Table(show_header=True, header_style="bold")
        for key, label in columns:
            justify = "right" if key in {"CPU", "GPU", "Size", "Price", "InstancePrice"} else "left"
            if key == "ResourceId":
                table.add_column(tr(label), justify=justify, min_width=24, no_wrap=True)
            else:
                table.add_column(tr(label), justify=justify)
        count = 0
        for row in rows or ():
            count += 1
            table.add_row(*(self._cell(row.get(key), key=key) for key, _ in columns))
        if count:
            self.console.print(table)
        else:
            self.console.print(
                tr("No results. Try adjusting the filters or checking the selected region.")
            )

    def success(self, message: str, response: Dict[str, Any]) -> None:
        if self.json_output:
            self.data(response)
        else:
            self.console.print(f"[green]✓[/green] {message}")

    def details(
        self,
        title: str,
        fields: Sequence[Tuple[str, Any]],
        *,
        response: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Render a compact human detail card while preserving raw JSON output."""
        if self.json_output:
            self.data(response or {key: value for key, value in fields})
            return
        grid = Table.grid(padding=(0, 2))
        grid.add_column(style="bold cyan", no_wrap=True)
        grid.add_column(overflow="fold")
        for label, value in fields:
            grid.add_row(tr(label), self._cell(value, key=label))
        self.console.print(Panel(grid, title=tr(title), border_style="blue"))

    def error(self, message: str, *, details: Optional[Dict[str, Any]] = None) -> None:
        if self.json_output:
            self._write_error("command_error", message, details)
        else:
            Console(stderr=True).print(f"[red]{tr('Error')}:[/red] {message}")

    def coded_error(
        self,
        code: str,
        message: str,
        *,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        if self.json_output:
            self._write_error(code, message, details)
        else:
            Console(stderr=True).print(f"[red]{tr('Error')}:[/red] {message}")

    def _write_success(self, data: Any, metadata: Optional[Dict[str, Any]] = None) -> None:
        safe_data, redacted = _sanitized_with_paths(
            data,
            show_sensitive=self.show_sensitive,
            path="data",
        )
        payload: Dict[str, Any] = {
            "ok": True,
            "schema_version": JSON_SCHEMA_VERSION,
            "data": safe_data,
        }
        safe_metadata, metadata_redacted = _sanitized_with_paths(
            dict(metadata or {}),
            show_sensitive=self.show_sensitive,
            path="meta",
        )
        redacted.extend(metadata_redacted)
        if redacted:
            safe_metadata["redacted_fields"] = redacted
        if safe_metadata:
            payload["meta"] = safe_metadata
        _write_json(payload)

    def _write_error(
        self,
        code: str,
        message: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        error: Dict[str, Any] = {"code": code, "message": message}
        redacted: List[str] = []
        if details:
            safe_details, redacted = _sanitized_with_paths(
                details,
                show_sensitive=self.show_sensitive,
                path="error.details",
            )
            error["details"] = safe_details
        payload: Dict[str, Any] = {
            "ok": False,
            "schema_version": JSON_SCHEMA_VERSION,
            "error": error,
        }
        if redacted:
            payload["meta"] = {"redacted_fields": redacted}
        _write_json(payload)

    def _response_error(self, response: Dict[str, Any]) -> None:
        raw_error = response.get("error")
        details = {
            key: value
            for key, value in response.items()
            if key not in {"ok", "error", "error_code", "message"}
        }
        if isinstance(raw_error, dict):
            code = str(raw_error.get("code") or "operation_failed")
            message = str(raw_error.get("message") or "Operation failed.")
            for key, value in raw_error.items():
                if key not in {"code", "message"}:
                    details.setdefault(key, value)
        else:
            code = str(response.get("error_code") or "operation_failed")
            message = str(raw_error or response.get("message") or "Operation failed.")
        self._write_error(code, message, details or None)

    def _cell(self, value: Any, *, key: Optional[str] = None) -> str:
        if value is None:
            return "-"
        if key and not self.show_sensitive and _is_sensitive_key(key):
            return "***"
        if isinstance(value, bool):
            return tr("yes") if value else tr("no")
        if isinstance(value, (dict, list)):
            return json.dumps(
                sanitized(value, show_sensitive=self.show_sensitive),
                ensure_ascii=False,
                separators=(",", ":"),
            )
        if key and "time" in key.casefold() and isinstance(value, (int, float)):
            return datetime.fromtimestamp(value).astimezone().strftime("%Y-%m-%d %H:%M:%S")
        if key and key.casefold() in {"state", "status"}:
            state = str(value)
            normalized = state.casefold()
            display = tr(state)
            if normalized in {"running", "available", "success", "succeeded"}:
                return f"[green]{display}[/green]"
            if normalized in {"failed", "error", "terminated"}:
                return f"[red]{display}[/red]"
            if normalized not in {"stopped", "closed"}:
                return f"[yellow]{display}[/yellow]"
        return str(value)

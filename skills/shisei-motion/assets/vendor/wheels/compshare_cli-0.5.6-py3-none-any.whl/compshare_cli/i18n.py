from __future__ import annotations

import os
from typing import Dict

import click

from compshare_cli.config import ConfigStore
from compshare_cli.errors import ConfigError, UsageError

DEFAULT_LANGUAGE = "zh"

ZH_TRANSLATIONS: Dict[str, str] = {
    "Manage CompShare GPU compute from the terminal.": "在终端管理优云智算 GPU 计算资源。",
    "Manage CompShare GPU compute and MiniMax H3 from the terminal.": (
        "在终端管理优云智算 GPU 计算资源和 MiniMax H3。"
    ),
    "Emit machine-readable JSON.": "输出机器可读的 JSON。",
    "Show passwords, IP addresses, access URLs, and login commands.": (
        "显示密码、IP 地址、访问 URL 和登录命令。"
    ),
    "Credential profile.": "凭证配置名称。",
    "Credential profile name.": "凭证配置的名称。",
    "API public key.": "API 公钥。",
    "Make this profile the default.": "将此凭证设为默认配置。",
    "Region for this request; not part of the credential profile.": (
        "本次请求的地域，不属于凭证配置。"
    ),
    "Availability zone for this request; not part of the credential profile.": (
        "本次请求的可用区，不属于凭证配置。"
    ),
    "Language: zh or en.": "语言：zh 或 en。",
    "Install completion for the current shell.": "为当前 Shell 安装命令补全。",
    "Save a CompShare API credential profile.": "保存优云智算 API 凭证配置。",
    "Print the CLI version.": "显示 CLI 版本。",
    "Print the CLI version and exit.": "显示 CLI 版本并退出。",
    "Manage GPU instances.": "管理 GPU 实例。",
    "Manage dedicated bandwidth.": "管理独享带宽。",
    "List dedicated bandwidth resources.": "列出独享带宽资源。",
    "List instance EIP bandwidth assignments.": "列出实例 EIP 的带宽归属。",
    "Purchase dedicated bandwidth after quoting the price.": "询价后购买独享带宽。",
    "Change a dedicated bandwidth limit after quoting the price.": "询价后修改独享带宽上限。",
    "Delete dedicated bandwidth after quoting the refund.": "询价后删除独享带宽。",
    "Switch instance EIPs between dedicated and shared bandwidth.": (
        "在独享带宽和共享带宽之间切换实例 EIP。"
    ),
    "Bandwidth limit in Mbps (20-10000).": "带宽上限，单位 Mbps（20–10000）。",
    "Billing type: Month or Year.": "计费方式：Month 或 Year。",
    "Quote and show the request without purchasing bandwidth.": (
        "仅询价并显示请求，不购买独享带宽。"
    ),
    "Dedicated bandwidth ID.": "独享带宽 ID。",
    "Target bandwidth limit in Mbps (20-10000).": "目标带宽上限，单位 Mbps（20–10000）。",
    "Quote and show the request without changing bandwidth.": (
        "仅询价并显示请求，不修改独享带宽。"
    ),
    "Quote and show the request without deleting bandwidth.": (
        "仅询价并显示请求，不删除独享带宽。"
    ),
    "Target bandwidth: dedicated or shared.": "目标带宽：dedicated 或 shared。",
    "--charge must be Month or Year.": "--charge 必须是 Month 或 Year。",
    "--to must be dedicated or shared.": "--to 必须是 dedicated 或 shared。",
    "Refund {amount} CNY": "预计退还 {amount} 元",
    "Payment {amount} CNY": "需支付 {amount} 元",
    "Migrate bound EIPs to shared bandwidth, then delete": ("将已绑定 EIP 迁移到共享带宽后删除"),
    "The API returned no result for instance {instance}.": (
        "API 未返回实例 {instance} 的操作结果。"
    ),
    "Some bandwidth switches failed.": "部分带宽切换失败。",
    "dedicated": "独享带宽",
    "shared": "共享带宽",
    "blocked": "已拦截",
    "Manage MiniMax H3 video, image, and audio tasks.": "管理 MiniMax H3 视频、图片和音频任务。",
    "Create a MiniMax H3 video task.": "创建 MiniMax H3 视频任务。",
    "Show a MiniMax H3 video task.": "查看 MiniMax H3 视频任务。",
    "List MiniMax H3 video tasks.": "列出 MiniMax H3 视频任务。",
    "List MiniMax H3 point packages.": "列出 MiniMax H3 积分套餐包。",
    "Show the MiniMax H3 point balance.": "查看 MiniMax H3 积分余额。",
    "Cancel an unfinished MiniMax H3 video task.": "取消尚未结束的 MiniMax H3 视频任务。",
    "Video prompt; at most 7000 characters.": "视频提示词，最多 7000 个字符。",
    "Model: MiniMax-H3 or minimax-h3-lite.": "模型：MiniMax-H3 或 minimax-h3-lite。",
    "Output resolution: 480P, 768P, 1080P, 2K, or 4K.": (
        "输出分辨率：480P、768P、1080P、2K 或 4K。"
    ),
    "Video duration in seconds (4-30).": "视频时长秒数（4–30）。",
    "Output ratio or adaptive for media input.": "输出宽高比；素材输入可使用 adaptive。",
    "First-frame image URL or Data URL.": "首帧图片 URL 或 Data URL。",
    "Last-frame image URL or Data URL.": "尾帧图片 URL 或 Data URL。",
    "Reference image URL or Data URL; repeatable.": "参考图片 URL 或 Data URL，可重复指定。",
    "Reference video URL or Data URL; repeatable.": "参考视频 URL 或 Data URL，可重复指定。",
    "Reference audio URL or Data URL; repeatable.": "参考音频 URL 或 Data URL，可重复指定。",
    "Enable Context-IR prompt optimization.": "启用 Context-IR 提示词优化。",
    "Skill ID; requires --context-ir.": "Skill ID；需要同时指定 --context-ir。",
    "Remove the video audio track.": "移除视频音轨。",
    "Add an AIGC watermark.": "添加 AIGC 水印。",
    "Public task callback URL.": "可公开访问的任务回调 URL。",
    "Idempotency key; generated automatically when omitted.": "幂等键；省略时自动生成。",
    "Show the request without creating a video task.": "仅显示请求，不创建视频任务。",
    "Video task ID.": "视频任务 ID。",
    "Page number starting at 1.": "页码，从 1 开始。",
    "Results per page (1-100).": "每页结果数（1–100）。",
    "Filter by task status.": "按任务状态筛选。",
    "Filter by model.": "按模型筛选。",
    "Set {environment} to a MiniMax H3 API key.": (
        "请将 {environment} 设置为 MiniMax H3 API Key。"
    ),
    "{environment} must contain an sk-ml- API key.": (
        "{environment} 必须是以 sk-ml- 开头的 API Key。"
    ),
    "MiniMax H3 API rejected the request with HTTP {status}.": (
        "MiniMax H3 API 拒绝了请求，HTTP 状态码为 {status}。"
    ),
    "Unable to reach the MiniMax H3 API.": "无法连接 MiniMax H3 API。",
    "MiniMax H3 API returned an invalid response.": "MiniMax H3 API 返回了无效响应。",
    "MiniMax H3 API rejected the request.": "MiniMax H3 API 拒绝了请求。",
    "Prompt cannot be empty.": "提示词不能为空。",
    "Prompt cannot exceed 7000 characters.": "提示词不能超过 7000 个字符。",
    "Frame inputs cannot be combined with reference inputs.": (
        "首尾帧素材不能与参考图片、视频或音频混用。"
    ),
    "{option} may be specified at most {maximum} times.": ("{option} 最多可指定 {maximum} 次。"),
    "At most 12 reference inputs are allowed.": "参考素材合计最多 12 个。",
    "Reference audio requires a reference image or video.": (
        "参考音频需要同时指定参考图片或视频。"
    ),
    "Unsupported video model: {model}.": "不支持的视频模型：{model}。",
    "--resolution must be 480P, 768P, 1080P, 2K, or 4K.": (
        "--resolution 必须是 480P、768P、1080P、2K 或 4K。"
    ),
    "--skill-id requires --context-ir.": "--skill-id 需要同时指定 --context-ir。",
    "Unsupported video ratio: {ratio}.": "不支持的视频宽高比：{ratio}。",
    "Unsupported task status: {status}.": "不支持的任务状态：{status}。",
    "Video task": "视频任务",
    "Image task": "图片任务",
    "Speech task": "语音任务",
    "Point balance": "积分余额",
    "REFERENCES": "参考素材数",
    "VOICE SOURCE": "音色来源",
    "TEXT LENGTH": "正文长度",
    "CONTENT TYPE": "内容类型",
    "OUTPUT URL": "成品 URL",
    "SKILL ID": "Skill ID",
    "OFFICIAL": "官方",
    "FILE": "文件",
    "Generate images and manage image tasks.": "生成图片并管理图片任务。",
    "Show image generation availability and prices.": "查看图片生成服务状态和价格。",
    "Create a Qwen-Image task.": "创建 Qwen-Image 任务。",
    "Show an image task.": "查看图片任务。",
    "List image tasks.": "列出图片任务。",
    "Cancel a queued image task.": "取消排队中的图片任务。",
    "Delete a finished image task and its output.": "删除已完成的图片任务及成品。",
    "Upload and register a reference image.": "上传并登记参考图片。",
    "Image prompt; at most 7000 characters.": "图片提示词，最多 7000 个字符。",
    "Image resolution: 1K or 2K.": "图片分辨率：1K 或 2K。",
    "Image aspect ratio.": "图片宽高比。",
    "Registered reference image asset ID; repeatable.": "已登记的参考图片素材 ID，可重复指定。",
    "Optimize the prompt.": "优化提示词。",
    "Idempotency key.": "幂等键。",
    "Show the request only.": "仅显示请求。",
    "Task status; repeatable.": "任务状态，可重复指定。",
    "latest or oldest.": "latest 或 oldest。",
    "Actual image width in pixels.": "图片实际宽度，单位像素。",
    "Actual image height in pixels.": "图片实际高度，单位像素。",
    "Generate speech and manage audio tasks.": "生成语音并管理音频任务。",
    "Show speech pricing and point balance.": "查看语音价格和积分余额。",
    "List preset or custom voices.": "列出预设或自定义音色。",
    "Create an IndexTTS 2.5 speech task.": "创建 IndexTTS 2.5 语音任务。",
    "Show a speech task.": "查看语音任务。",
    "List speech tasks.": "列出语音任务。",
    "Cancel a queued speech task.": "取消排队中的语音任务。",
    "Delete a finished speech task and its output.": "删除已完成的语音任务及成品。",
    "Upload and register reference audio.": "上传并登记参考音频。",
    "Save a reference asset as a custom voice.": "将参考音频素材保存为自定义音色。",
    "Delete a custom voice.": "删除自定义音色。",
    "preset or custom.": "preset 或 custom。",
    "Speech text; at most 2000 characters.": "语音正文，最多 2000 个字符。",
    "preset, custom, or asset.": "preset、custom 或 asset。",
    "Preset or custom voice ID.": "预设或自定义音色 ID。",
    "Registered reference audio asset ID.": "已登记的参考音频素材 ID。",
    "ZH, EN, JA, ES, or AR.": "ZH、EN、JA、ES 或 AR。",
    "Speech speed (0 or 0.5-2.0).": "语速（0 或 0.5–2.0）。",
    "Emotion description.": "情绪描述。",
    "Emotion strength (0-1).": "情绪强度（0–1）。",
    "Eight comma-separated emotion values.": "以逗号分隔的八个情绪数值。",
    "single or mixed.": "single 或 mixed。",
    "WORD:KIND:VALUE; repeatable.": "WORD:KIND:VALUE，可重复指定。",
    "Save asset as a custom voice.": "将素材保存为自定义音色。",
    "Name for a saved custom voice.": "保存的自定义音色名称。",
    "Actual duration in milliseconds.": "实际时长，单位毫秒。",
    "Custom voice name.": "自定义音色名称。",
    "Manage MiniMax H3 video Skills.": "管理 MiniMax H3 视频 Skill。",
    "List official and custom video Skills.": "列出官方和自定义视频 Skill。",
    "Create a custom video Skill.": "创建自定义视频 Skill。",
    "Replace a custom video Skill.": "替换自定义视频 Skill。",
    "Delete a custom video Skill.": "删除自定义视频 Skill。",
    "Idempotency key must contain 1-128 characters.": "幂等键长度须为 1–128 个字符。",
    "File size must be between 1 and {maximum} bytes.": "文件大小须在 1 到 {maximum} 字节之间。",
    "API returned an invalid upload URL.": "API 返回的上传 URL 无效。",
    "API returned no upload object key.": "API 未返回上传对象标识。",
    "API returned incomplete upload credentials.": "API 返回的上传凭证不完整。",
    "File changed while preparing the upload.": "准备上传时文件发生变化。",
    "Reference upload failed with HTTP {status}.": "参考素材上传失败，HTTP 状态码为 {status}。",
    "Unable to upload the reference file.": "无法上传参考素材文件。",
    "Image prompt must contain 1-7000 characters.": "图片提示词须包含 1–7000 个字符。",
    "Image resolution must be 1K or 2K.": "图片分辨率须为 1K 或 2K。",
    "Unsupported image ratio: {ratio}.": "不支持的图片宽高比：{ratio}。",
    "At most 10 reference images are allowed.": "参考图片最多 10 张。",
    "Sort must be latest or oldest.": "排序方式须为 latest 或 oldest。",
    "Image file must be JPG, PNG, or WebP.": "图片文件须为 JPG、PNG 或 WebP。",
    "Voice kind must be preset or custom.": "音色类型须为 preset 或 custom。",
    "Emotion vector must contain eight numbers.": "情绪向量须包含八个数字。",
    "Emotion vector must contain eight values between 0 and 0.8.": (
        "情绪向量须包含八个介于 0 和 0.8 之间的值。"
    ),
    "Emotion vector sum must be greater than 0 and at most 0.8.": (
        "情绪向量总和须大于 0 且不超过 0.8。"
    ),
    "Single emotion mode requires exactly one nonzero value.": (
        "single 情绪模式须恰有一个非零值。"
    ),
    "At most 100 pronunciation rules are allowed.": "读音规则最多 100 条。",
    "Pronunciation must be WORD:KIND:VALUE.": "读音规则格式须为 WORD:KIND:VALUE。",
    "Invalid pronunciation word or kind.": "读音规则的词语或类型无效。",
    "Invalid or duplicate pronunciation rule.": "读音规则无效或重复。",
    "Speech text must contain 1-2000 characters of letters or digits.": (
        "语音正文须包含字母或数字，且不超过 2000 个字符。"
    ),
    "Unsupported speech language: {language}.": "不支持的语音语言：{language}。",
    "Speech speed must be 0 or between 0.5 and 2.0.": "语速须为 0 或介于 0.5 和 2.0 之间。",
    "Emotion strength must be between 0 and 1.": "情绪强度须介于 0 和 1 之间。",
    "Voice source must be preset, custom, or asset.": "音色来源须为 preset、custom 或 asset。",
    "Asset voice requires --asset-id and no --voice-id.": (
        "素材音色须指定 --asset-id，且不能指定 --voice-id。"
    ),
    "Preset or custom voice requires --voice-id and no --asset-id.": (
        "预设或自定义音色须指定 --voice-id，且不能指定 --asset-id。"
    ),
    "--save-voice requires an asset voice and a name of 1-64 characters.": (
        "--save-voice 须使用素材音色，并指定 1–64 个字符的名称。"
    ),
    "--voice-name requires --save-voice.": "--voice-name 需要同时指定 --save-voice。",
    "Emotion description cannot exceed 200 characters.": "情绪描述不能超过 200 个字符。",
    "Emotion vector mode must be single or mixed.": "情绪向量模式须为 single 或 mixed。",
    "Emotion vector mode requires --emotion-vector.": (
        "情绪向量模式需要同时指定 --emotion-vector。"
    ),
    "Emotion vector requires --no-auto-emotion and no description.": (
        "情绪向量需要指定 --no-auto-emotion，且不能指定情绪描述。"
    ),
    "Audio file name cannot exceed 255 characters.": "音频文件名不能超过 255 个字符。",
    "Audio file must be WAV, MP3, FLAC, OGG, or M4A.": (
        "音频文件须为 WAV、MP3、FLAC、OGG 或 M4A。"
    ),
    "Voice name must contain 1-64 characters.": "音色名称长度须为 1–64 个字符。",
    "Skill name and content cannot be empty.": "Skill 名称和内容不能为空。",
    "Skill request cannot exceed 64 KiB.": "Skill 请求体不能超过 64 KiB。",
    "Manage durable remote instance jobs.": "管理可断线恢复的实例远程任务。",
    "Submit a durable remote job and return immediately.": "提交持久化远程任务并立即返回。",
    "List durable remote jobs on an instance.": "列出实例上的持久化远程任务。",
    "Show durable remote job status and metadata.": "显示远程任务状态和元数据。",
    "Read or follow durable remote job logs.": "读取或持续跟踪远程任务日志。",
    "Wait for a durable remote job without cancelling on timeout.": (
        "等待远程任务；等待超时不会取消任务。"
    ),
    "Cancel a running durable remote job.": "取消正在运行的远程任务。",
    "Remove old terminal remote job records and logs.": "清理已结束远程任务的记录和日志。",
    "Human-readable job name.": "便于识别的任务名称。",
    "Remote working directory.": "远程工作目录。",
    "Client-generated idempotency key; generated automatically when omitted.": (
        "客户端生成的幂等键；省略时自动生成。"
    ),
    "Remote job ID.": "远程任务 ID。",
    "Filter by job state.": "按任务状态筛选。",
    "Number of trailing lines.": "显示末尾日志行数。",
    "Follow logs until completion.": "持续跟踪日志直到任务结束。",
    "Log stream: all, stdout, or stderr.": "日志流：all、stdout 或 stderr。",
    "Read stdout from this byte offset instead of tailing lines.": (
        "从该字节偏移读取 stdout，不使用末尾行模式。"
    ),
    "Read stderr from this byte offset instead of tailing lines.": (
        "从该字节偏移读取 stderr，不使用末尾行模式。"
    ),
    "Maximum bytes to read from each stream in offset mode.": (
        "偏移读取模式下每个日志流的最大字节数。"
    ),
    "Polling interval in seconds.": "轮询间隔秒数。",
    "Kill the remote process group immediately.": "立即强制终止远程进程组。",
    "Minimum terminal job age, for example 12h or 7d.": (
        "已结束任务的最短保留时间，例如 12h 或 7d。"
    ),
    "List jobs without removing them.": "只列出任务，不执行清理。",
    "Manage local instance configuration templates.": "管理本地实例配置模板。",
    "List local instance templates.": "列出本地实例模板。",
    "Show a local instance template.": "显示本地实例模板。",
    "Create a local instance template.": "创建本地实例模板。",
    "Delete a local instance template.": "删除本地实例模板。",
    "Print the local instance template file path.": "显示本地实例模板文件路径。",
    "Template name.": "模板名称。",
    "Template description.": "模板说明。",
    "Local instance template name; explicit options override template values.": (
        "本地实例模板名称；本次显式参数优先覆盖模板值。"
    ),
    "Replace an existing template.": "覆盖已有模板。",
    "Search legal specifications and, with --image, real inventory.": (
        "查询合法规格；指定 --image 时检查真实库存。"
    ),
    "GPU type; repeatable.": "GPU 型号，可重复指定。",
    "Search interruptible instances.": "查询抢占式实例。",
    "Image ID. When set, check real inventory for every matched GPU type.": (
        "镜像 ID；指定后检查每个匹配 GPU 型号的真实库存。"
    ),
    "Show only in-stock specs.": "只显示有库存的规格。",
    "Availability zone.": "可用区。",
    "Availability zone for this request.": "本次请求的可用区。",
    "CPU platform for stock checks.": "库存检查使用的 CPU 平台。",
    "Billing type for stock checks.": "库存检查使用的计费方式。",
    "Boot disk size for stock checks.": "库存检查使用的系统盘大小。",
    "List supported regions and availability zones.": "列出支持的地域和可用区。",
    "List GPU machine families.": "列出 GPU 机型族。",
    "List instances.": "列出实例。",
    "Instance ID; repeatable.": "实例 ID，可重复指定。",
    "Filter hosts compatible with a disk.": "筛选可挂载指定云盘的实例。",
    "Project ID for this request.": "本次请求使用的项目 ID。",
    "Show full instance details.": "显示实例完整信息。",
    "Instance ID.": "实例 ID。",
    "Show only instance IP information.": "只显示实例 IP 信息。",
    "Show only exposed software applications and URLs.": "只显示对外开放的软件及其 URL。",
    "Show only compute specifications.": "只显示计算规格。",
    "Show only disk and volume information.": "只显示磁盘和存储卷信息。",
    "Show only billing information.": "只显示计费信息。",
    "Show only image information.": "只显示镜像信息。",
    "Show only state and lifecycle times.": "只显示状态和生命周期时间。",
    "Create instances interactively, or use explicit options for automation.": (
        "通过交互向导创建实例，也可显式传参用于自动化。"
    ),
    "GPU type, for example 4090.": "GPU 型号，例如 4090。",
    "GPU count.": "GPU 数量。",
    "Memory, for example 64GiB.": "内存大小，例如 64GiB。",
    "CompShare image ID.": "优云智算镜像 ID。",
    "Image source: platform, custom, community or shared.": (
        "镜像来源：platform、custom、community 或 shared。"
    ),
    "Boot disk size.": "系统盘大小。",
    "Boot disk type.": "系统盘类型。",
    "Data disk as SIZE[:TYPE]; repeatable.": "数据盘，格式为 SIZE[:TYPE]，可重复指定。",
    "Billing type.": "计费方式。",
    "Skip confirmation.": "跳过确认。",
    "A or B.": "无卡规格 A 或 B。",
    "Start an instance.": "启动实例。",
    "Stop an instance.": "停止实例。",
    "Reboot an instance.": "重启实例。",
    "Permanently delete an instance.": "永久删除实例。",
    "Rename an instance.": "修改实例名称。",
    "Reset an instance password.": "重置实例密码。",
    "Reinstall an instance from an image.": "使用镜像重装实例。",
    "Change instance CPU, memory, GPU or disk size.": "调整实例的 CPU、内存、GPU 或磁盘大小。",
    "Query a new instance price.": "查询新实例价格。",
    "Query the price of an instance upgrade.": "查询实例升配价格。",
    "Query current instance pricing.": "查询实例当前计费价格。",
    "Query instance refund amounts.": "查询实例退款金额。",
    "Get instance monitoring data.": "获取实例监控数据。",
    "Monitoring requires UHostIds to be an array of strings.": (
        "监控请求的 UHostIds 必须为字符串数组。"
    ),
    "No monitoring data returned for the selected instances.": "所选实例暂无监控数据。",
    "Change an instance billing type.": "变更实例计费方式。",
    "Check network accelerator status.": "检查网络加速状态。",
    "List models in the model repository.": "列出模型仓库中的模型。",
    "Shared storage as SIZE[:TYPE]; repeatable.": "共享存储，格式为 SIZE[:TYPE]，可重复指定。",
    "Month, Day, Dynamic or Postpay.": "目标计费方式：Month、Day、Dynamic 或 Postpay。",
    "Print instead of executing SSH.": "只显示 SSH 命令，不执行连接。",
    "Automatically enter the password returned by the API.": "自动填写 API 返回的登录密码。",
    "Wait for the instance to be running before connecting.": "连接前等待实例进入运行状态。",
    "Maximum SSH connection time in seconds.": "SSH 建立连接的最长时间（秒）。",
    "Cache SSH connection data to avoid repeated instance queries.": (
        "缓存 SSH 连接信息，避免重复查询实例。"
    ),
    "SSH connection cache lifetime in seconds.": "SSH 连接缓存的有效期（秒）。",
    "Refresh SSH connection data from the API before connecting.": (
        "连接前从 API 强制刷新 SSH 连接信息。"
    ),
    "Remote command and arguments; use -- before command options.": (
        "要在实例中执行的命令及参数；命令包含选项时请先使用 -- 分隔。"
    ),
    "Copy files or directories between local machine and an instance.": (
        "在本地与实例之间双向复制文件或目录。"
    ),
    "Source path. Prefix instance paths with :.": "源路径；实例路径需要以 : 开头。",
    "Destination path. Prefix instance paths with :.": "目标路径；实例路径需要以 : 开头。",
    "Print instead of copying.": "只显示 SCP 命令，不执行复制。",
    "Open or print an instance SSH command.": "连接实例 SSH，或仅显示 SSH 命令。",
    "Manage container port mappings.": "管理容器端口映射。",
    "List supported software ports.": "列出平台支持的软件端口。",
    "Replace an instance's container port mappings.": "替换实例的容器端口映射。",
    "Manage scheduled shutdowns.": "管理定时关机。",
    "Schedule an instance shutdown.": "设置实例定时关机。",
    "Show an instance scheduled shutdown.": "查询实例定时关机。",
    "Extend an instance scheduled shutdown.": "延后实例定时关机。",
    "Cancel an instance scheduled shutdown.": "取消实例定时关机。",
    "Positive duration to add to the current shutdown time, for example 2h.": (
        "在当前关机时间上增加的正时长，例如 2h。"
    ),
    "Unix timestamp or ISO 8601 time.": "Unix 时间戳或 ISO 8601 时间。",
    "Discover software exposed by instances.": "查询实例提供的软件入口。",
    "List supported instance software.": "列出实例支持的软件。",
    "Get an instance software access URL.": "获取实例软件的访问地址。",
    "Get an instance software access URL (currently unavailable in production).": (
        "获取实例软件的访问地址（生产环境当前不可用）。"
    ),
    "Manage instance images.": "管理实例镜像。",
    "List platform, custom, community, shared or published images.": (
        "列出平台、自制、社区、共享或已发布镜像。"
    ),
    "Fuzzy name or author search.": "按名称或作者模糊搜索。",
    "Community sort field.": "社区镜像排序字段。",
    "Organization ID for source=user.": "source=user 时使用的组织 ID。",
    "Create a custom image from an instance.": "从实例创建自制镜像。",
    "Show image details.": "显示镜像详情。",
    "Get custom image creation progress.": "查询自制镜像创建进度。",
    "Update image metadata.": "更新镜像元数据。",
    "Permanently delete a custom image.": "永久删除自制镜像。",
    "List accounts an image is shared with.": "列出镜像已共享的账户。",
    "Share an image with accounts.": "将镜像共享给指定账户。",
    "Remove image sharing from accounts.": "取消向指定账户共享镜像。",
    "Publish an image to the community.": "将镜像发布到社区。",
    "Add an image to favorites.": "收藏镜像。",
    "Remove an image from favorites.": "取消收藏镜像。",
    "List available image tags.": "列出可用的镜像标签。",
    "Manage disks and cloud storage.": "管理磁盘和云存储。",
    "Manage CFS file storage for container instances.": "管理容器实例的云存储 Pro（CFS）。",
    "List CFS file storage without pagination.": "查询全部 CFS，无需分页。",
    "Show a CFS resource and its mounted instances.": "查看 CFS 详情及挂载实例。",
    "Query the CFS purchase price in CNY.": "查询 CFS 购买价格，单位元。",
    "Purchase CFS storage after quoting the price.": "询价后购买 CFS。",
    "Query the CFS expansion price in CNY.": "查询 CFS 扩容价格，单位元。",
    "Expand CFS storage after quoting the price.": "询价后扩容 CFS。",
    "Query the estimated CFS refund in CNY.": "查询 CFS 预计退费金额，单位元。",
    "Permanently delete CFS storage after quoting the refund.": "预估退费后永久删除 CFS。",
    "Attach CFS; may purchase storage and restart the instance.": (
        "挂载 CFS，可能购买存储并重启实例。"
    ),
    "Detach CFS; running instances will restart.": "卸载 CFS，运行中的实例会重启。",
    "Attach existing CFS during container creation; does not purchase storage.": (
        "创建容器实例时挂载已有 CFS，不会购买存储。"
    ),
    "CFS ID.": "CFS ID。",
    "CFS name.": "CFS 名称。",
    "CFS capacity, for example 100GiB (50-2048 GiB).": "CFS 容量，例如 100GiB（50-2048 GiB）。",
    "Target CFS capacity, not an increment (50-2048 GiB).": (
        "扩容后的 CFS 总容量，非增量（50-2048 GiB）。"
    ),
    "CFS name cannot be empty.": "CFS 名称不能为空。",
    "CFS size must be between 50 and 2048 GiB.": "CFS 容量必须在 50 到 2048 GiB 之间。",
    "CFS requires a container availability zone.": "CFS 仅支持容器可用区。",
    "CFS attachments require a cpod- instance ID.": "CFS 挂载和卸载需要 cpod- 开头的实例 ID。",
    "Project ID.": "项目 ID。",
    "Quote and show the request only.": "仅询价并展示请求。",
    "Detach stopped instances before deleting CFS.": "删除 CFS 前先卸载已停止实例的挂载。",
    "Submitted CFS attachment for {instance}": "已为 {instance} 提交 CFS 挂载请求",
    "Attach CFS to {instance}? If none exists in this zone, this purchases 50 GiB "
    "for one month. Running instances may restart; save your work first.": (
        "确认给 {instance} 挂载 CFS？若该可用区尚无 CFS，将购买 50 GiB、按月计费 1 个周期的存储。"
        "运行中的实例可能重启，请先保存任务。"
    ),
    "Detach CFS from {instance}? Running instances will restart; save your work first.": (
        "确认从 {instance} 卸载 CFS？运行中的实例会重启，请先保存任务。"
    ),
    "Permanently delete CFS {cfs} and all its data? Back up your data first.": (
        "确认永久删除 CFS {cfs} 及其全部数据？请先备份。"
    ),
    "CFS ID": "CFS ID",
    "ZONE ID": "可用区 ID",
    "SIZE (GiB)": "容量（GiB）",
    "MOUNT STATUS": "挂载状态",
    "INSTANCES": "实例",
    "RECYCLE": "删除前卸载已停止实例",
    "PRICE (CNY)": "价格（元）",
    "REFUND (CNY)": "退费（元）",
    "Manage instance disks.": "管理实例云盘。",
    "List attached and detached disks from the disk inventory.": "列出已挂载和未挂载的云盘。",
    "List disks reported by one or all instances.": "列出一个或全部实例的磁盘。",
    "Create a disk and attach it to an instance.": "创建云盘并挂载到实例。",
    "Disk size, for example 100GiB.": "磁盘大小，例如 100GiB。",
    "Device path, for example /dev/vdb.": "设备路径，例如 /dev/vdb。",
    "Attach an existing disk to an instance.": "将已有云盘挂载到实例。",
    "Detach a disk from an instance.": "从实例卸载云盘。",
    "Query a disk expansion price.": "查询云盘扩容价格。",
    "Resize a disk.": "扩容云盘。",
    "Permanently delete a disk.": "永久删除云盘。",
    "Manage US3 attachments.": "管理 US3 挂载。",
    "Attach US3 object storage to an instance.": "将 US3 对象存储挂载到实例。",
    "No results. Try adjusting the filters or checking the selected region.": (
        "没有结果，请调整筛选条件或检查所选地域。"
    ),
    "Error": "错误",
    "yes": "是",
    "no": "否",
    "Public key": "公钥",
    "Private key": "私钥",
    "New password": "新密码",
    "Select": "请选择",
    "Aborted": "操作已取消",
    "Please enter y or n.": "请输入 y 或 n。",
    "JSON mode cannot prompt for confirmation; pass --yes to confirm the operation.": (
        "JSON 模式不能交互确认；请传入 --yes 确认执行操作。"
    ),
    "Attach US3 during container creation.": "创建容器实例时挂载 US3。",
    "Attached instance ID.": "已挂载的实例 ID。",
    "Backup mode: NONE, DATAARK or SNAPSHOT.": "备份模式：NONE、DATAARK 或 SNAPSHOT。",
    "Billing duration for prepaid modes.": "预付费模式的购买时长。",
    "Boot disk type used for stock checks.": "库存检查使用的系统盘类型。",
    "CPU core count.": "CPU 核数。",
    "Community image description.": "社区镜像描述。",
    "Community image name.": "社区镜像名称。",
    "Community version group ID.": "社区镜像版本组 ID。",
    "Community version name.": "社区镜像版本名称。",
    "Complete HTTP port list; repeatable.": "完整 HTTP 端口列表，可重复指定。",
    "Complete TCP port list; repeatable.": "完整 TCP 端口列表，可重复指定。",
    "Coupon ID.": "代金券 ID。",
    "Cover image file encoded as Base64.": "封面图片文件，将编码为 Base64。",
    "Custom image description.": "自制镜像描述。",
    "Custom image name.": "自制镜像名称。",
    "Data disk type.": "数据盘类型。",
    "Delete attached data disks with the instance.": "删除实例时同时删除已挂载的数据盘。",
    "Disk ID to resize.": "要扩容的磁盘 ID。",
    "Disk name.": "磁盘名称。",
    "Disk type.": "磁盘类型。",
    "Existing community version group ID.": "已有社区镜像版本组 ID。",
    "Filter by VPC ID.": "按 VPC ID 筛选。",
    "Filter by automatic startup support.": "按是否支持自动启动筛选。",
    "Filter by availability zone.": "按可用区筛选。",
    "Filter by exact image name.": "按镜像完整名称筛选。",
    "Filter by image ID.": "按镜像 ID 筛选。",
    "Filter by image author.": "按镜像作者筛选。",
    "Filter by image type.": "按镜像类型筛选。",
    "Filter by instance ID.": "按实例 ID 筛选。",
    "Filter by instance tag.": "按实例标签筛选。",
    "Filter by model name.": "按模型名称筛选。",
    "Filter by model tags.": "按模型标签筛选。",
    "Filter by subnet ID.": "按子网 ID 筛选。",
    "Filter by tag; repeatable.": "按标签筛选，可重复指定。",
    "Filter by version group ID.": "按版本组 ID 筛选。",
    "Filter free or paid community images.": "筛选免费或付费社区镜像。",
    "Filter official or community-authored images.": "筛选官方或社区作者镜像。",
    "GPU type.": "GPU 型号。",
    "Hourly image price.": "镜像每小时价格。",
    "Hourly image price; 0 means free.": "镜像每小时价格，0 表示免费。",
    "Image ID for image pricing.": "用于镜像计价的镜像 ID。",
    "Image source.": "镜像来源。",
    "Image source: platform, custom, community, shared, published or user.": (
        "镜像来源：platform、custom、community、shared、published 或 user。"
    ),
    "Image tag; repeatable.": "镜像标签，可重复指定。",
    "Instance name.": "实例名称。",
    "Instance remark.": "实例备注。",
    "List no-GPU instances.": "列出无 GPU 实例。",
    "Maximum number of results.": "最多返回的结果数量。",
    "Minimum CPU platform.": "最低 CPU 平台。",
    "New image description.": "新的镜像描述。",
    "New image name.": "新的镜像名称。",
    "No-GPU specification: A or B.": "无卡规格：A 或 B。",
    "Number of instances.": "实例数量。",
    "Number of results to skip.": "跳过的结果数量。",
    "Replacement image ID.": "重装使用的镜像 ID。",
    "Security group ID.": "安全组 ID。",
    "Sort in ascending order.": "按升序排列。",
    "Source instance ID.": "源实例 ID。",
    "Supported GPU type; repeatable.": "支持的 GPU 型号，可重复指定。",
    "Target CPU core count.": "目标 CPU 核数。",
    "Target GPU count.": "目标 GPU 数量。",
    "Target disk size, for example 200GiB.": "目标磁盘大小，例如 200GiB。",
    "Target instance ID.": "目标实例 ID。",
    "Target memory, for example 64GiB.": "目标内存，例如 64GiB。",
    "Target no-GPU specification: A or B.": "目标无卡规格：A 或 B。",
    "Target running instance ID.": "目标运行中实例 ID。",
    "UTF-8 README file.": "UTF-8 编码的 README 文件。",
    "Version description.": "版本描述。",
    "Version name.": "版本名称。",
    "Visibility: 0 private, 1 public.": "可见性：0 私有，1 公开。",
    "Whether the image supports automatic startup.": "镜像是否支持自动启动。",
    "Saved credential profile {name}": "已保存凭证配置 {name}",
    "Saved instance template {name}": "已保存实例模板 {name}",
    "Delete local instance template {name}?": "删除本地实例模板 {name}？",
    "Deleted instance template {name}": "已删除实例模板 {name}",
    "Instance template": "实例模板",
    "PARAMETERS": "参数",
    "UPDATED": "更新时间",
    "Invalid memory size: {value}. Example: 64GiB": "无效的内存大小：{value}。示例：64GiB",
    "Memory must be positive and resolve to whole GiB.": "内存必须大于 0，且换算后为整数 GiB。",
    "Invalid disk size: {value}. Example: 100GiB": "无效的磁盘大小：{value}。示例：100GiB",
    "Disk MiB must resolve to whole GiB.": "磁盘 MiB 数必须能换算成整数 GiB。",
    "Disk size must be positive.": "磁盘大小必须大于 0。",
    "Time must be a Unix timestamp, ISO 8601 value, or relative value like 30m or 2h.": (
        "时间必须是 Unix 时间戳、ISO 8601 时间，或 30m、2h 这样的相对时间。"
    ),
    "Unable to read file {path}: {error}": "无法读取文件 {path}：{error}",
    "Both source and destination cannot be instance paths.": "源路径和目标路径不能同时位于实例。",
    "Local destination parent {path} does not exist.": "本地目标路径的父目录 {path} 不存在。",
    "Remote path cannot be empty.": "实例路径不能为空。",
    "Wait for the operation to reach a stable state.": "等待操作进入稳定状态。",
    "Maximum wait time in seconds.": "最长等待时间（秒）。",
    "Validate and show the request without changing resources.": "仅校验并显示请求，不变更资源。",
    "Operation plan": "操作计划",
    "Create plan": "创建计划",
    "Instance details": "实例详情",
    "Image details": "镜像详情",
    "Storage details": "存储详情",
    "Confirm this operation?": "确认执行该操作？",
    "Dry run completed; no resources were changed.": "预演完成，未变更任何资源。",
    "Waiting for {instance}: {state}": "正在等待 {instance}：{state}",
    "Timed out after {timeout}s while waiting for {instance}.": (
        "等待 {instance} 超过 {timeout} 秒。可以用 `compshare instance show {instance}` 检查状态。"
    ),
    "Operation submitted": "操作已提交",
    "Operation completed": "操作已完成",
    "No selectable options": "没有可选项",
    "Automatically selected the only option.": "已自动选择唯一选项。",
    "Please enter a number from 1 to {count}.": "请输入 1 到 {count} 之间的数字。",
    "Page {page} of {pages} ({count} items)": "第 {page}/{pages} 页（共 {count} 项）",
    "Previous page": "上一页",
    "Next page": "下一页",
    "Please enter a listed number, f for next page, or b for previous page.": (
        "请输入当前页中的编号，或输入 f/b 翻页。"
    ),
    "Availability zone": "可用区",
    "GPU type": "GPU 型号",
    "Image source": "镜像来源",
    "Image": "镜像",
    "Billing type": "计费方式",
    "Available specification": "可用规格",
    "Filter images by name or ID (blank shows all)": "按名称或 ID 筛选镜像（留空显示全部）",
    "Boot disk size": "系统盘大小",
    "Boot disk type": "系统盘类型",
    "Password": "密码",
    "PROFILE": "配置",
    "ACTIVE": "当前",
    "ID": "ID",
    "NAME": "名称",
    "STATE": "状态",
    "GPU": "GPU",
    "COUNT": "数量",
    "CPU": "CPU",
    "MEMORY": "内存",
    "ZONE": "可用区",
    "REGION": "地域",
    "CHARGE": "计费",
    "PRICE/H": "每小时价格",
    "VRAM": "显存",
    "IN STOCK": "有库存",
    "CPU PLATFORM": "CPU 平台",
    "CPU ARCH": "CPU 架构",
    "IP SET": "IP 信息",
    "INSTANCE TYPE": "实例类型",
    "MACHINE TYPE": "机型",
    "SUPPORT WITHOUT GPU START": "支持无卡启动",
    "DISKS": "磁盘",
    "VOLUMES": "存储卷",
    "TOTAL DISK SPACE": "数据盘总空间",
    "TOTAL VOLUME SPACE": "共享存储总空间",
    "INSTANCE PRICE": "实例价格",
    "IMAGE PRICE": "镜像价格",
    "DISK PRICE": "磁盘价格",
    "DISK PRICE INFO": "磁盘计费详情",
    "DISCOUNT TYPE": "折扣类型",
    "AUTO RENEW": "自动续费",
    "IS EXPIRE": "是否过期",
    "EXPIRE TIME": "到期时间",
    "POWER-OFF BILLING": "关机后计费资源",
    "IMAGE NAME": "镜像名称",
    "IMAGE TYPE": "镜像类型",
    "IMAGE VERSION": "镜像版本",
    "IMAGE STATUS": "镜像状态",
    "IMAGE AUTHOR": "镜像作者",
    "OS": "操作系统",
    "OS TYPE": "操作系统类型",
    "BASIC IMAGE": "基础镜像",
    "BASIC IMAGE NAME": "基础镜像名称",
    "CREATE TIME": "创建时间",
    "START TIME": "启动时间",
    "STOP TIME": "关机时间",
    "UPDATE TIME": "更新时间",
    "SCHEDULER STOP TIME": "定时关机时间",
    "PREVIOUS STOP TIME": "原定时关机时间",
    "EXTENDED BY": "延后时长",
    "UNIX": "Unix 时间戳",
    "RELEASE TIME": "释放时间",
    "DESCRIPTION": "描述",
    "INSTANCE": "实例",
    "IMAGE": "镜像",
    "SYSTEM DISK": "系统盘",
    "DATA DISKS": "数据盘",
    "REFUND": "退款",
    "CODE": "代码",
    "MESSAGE": "信息",
    "BANDWIDTH ID": "独享带宽 ID",
    "BANDWIDTH (Mbps)": "带宽（Mbps）",
    "BANDWIDTH": "带宽",
    "TARGET BANDWIDTH": "目标带宽",
    "BANDWIDTH SCOPE": "带宽归属",
    "PUBLIC IP": "公网 IP",
    "EIP ID": "EIP ID",
    "EIPS": "EIP 数量",
    "CAN SWITCH": "可切换",
    "EXPIRES": "到期时间",
    "QUANTITY": "购买时长",
    "MIGRATED EIPS": "已迁移 EIP",
    "TARGET": "目标",
    "SUCCESS": "成功",
    "TASK ID": "任务 ID",
    "PACKAGE ID": "套餐包 ID",
    "MODEL": "模型",
    "RESOLUTION": "分辨率",
    "DURATION": "时长",
    "RATIO": "宽高比",
    "REMAINING (s)": "预计剩余（秒）",
    "TOTAL POINTS": "总积分",
    "RESERVED POINTS": "预占积分",
    "AVAILABLE POINTS": "可用积分",
    "IDEMPOTENCY KEY": "幂等键",
    "PROMPT": "提示词",
    "URL": "URL",
    "ERROR": "错误",
    "PATH": "路径",
    "TAG": "标签",
    "SIZE": "大小",
    "CREATED": "创建时间",
    "SOFTWARE": "软件",
    "PORT": "端口",
    "TYPE": "类型",
    "AUTHOR": "作者",
    "STATUS": "状态",
    "SOURCE": "来源",
    "VERSION": "版本",
    "TAGS": "标签",
    "METRIC": "指标",
    "VALUE (%)": "使用率（%）",
    "TIME": "采样时间",
    "ACCOUNT ID": "账户 ID",
    "ACCOUNT": "账户",
    "DISK ID": "云盘 ID",
    "BOOT": "系统盘",
    "DEVICE": "设备",
    "Manage credential profiles.": "管理 API 凭证配置。",
    "Create or update a credential profile.": "创建或更新凭证配置。",
    "List credential profiles.": "列出凭证配置。",
    "Set the default credential profile.": "设置默认凭证配置。",
    "Delete a credential profile.": "删除凭证配置。",
    "Show the configuration file path.": "显示配置文件路径。",
    "Filter by instance name.": "按实例名称筛选。",
    "Filter by instance state.": "按实例状态筛选。",
    "Filter by GPU type.": "按 GPU 型号筛选。",
    "Filter by billing type.": "按计费方式筛选。",
    "Filter by region.": "按地域筛选。",
    "Filter by region; must be used with --zone.": "按地域筛选，必须与 --zone 同时使用。",
    "Filter by availability zone; must be used with --region.": (
        "按可用区筛选，必须与 --region 同时使用。"
    ),
    "Region for this request.": "本次请求的地域。",
    "Unix timestamp, ISO 8601, or relative time.": "Unix 时间戳、ISO 8601 或相对时间。",
    "Override the automatically detected project ID.": "覆盖自动检测的项目 ID。",
    "Using credential profile {name}": "已切换到凭证配置 {name}",
    "Delete credential profile {name}?": "删除凭证配置 {name}？",
    "Deleted credential profile {name}": "已删除凭证配置 {name}",
    "--available requires --image because inventory depends on the image and disks.": (
        "--available 需要同时指定 --image，库存取决于镜像和磁盘组合。"
    ),
    "--disk and --disk-size must be used together.": "--disk 和 --disk-size 必须同时使用。",
    "--image-source must be platform, custom, community, or shared.": (
        "--image-source 必须是 platform、custom、community 或 shared。"
    ),
    "--source must be platform, custom, community, shared, published, or user.": (
        "--source 必须是 platform、custom、community、shared、published 或 user。"
    ),
    "--user is required for image source user.": "镜像来源为 user 时必须指定 --user。",
    "--without-gpu cannot be combined with --cpu, --memory, or --gpu.": (
        "--without-gpu 不能与 --cpu、--memory 或 --gpu 同时使用。"
    ),
    "--sort must be create_time, order_start_time, or order_end_time.": (
        "--sort 必须是 create_time、order_start_time 或 order_end_time。"
    ),
    "Hint": "建议",
    "The machine type API returned an unnamed GPU.": "机型接口返回了未命名的 GPU。",
    "Unnamed": "未命名",
    "Instance {instance} was not found.": "未找到实例 {instance}。",
    "DescribeCompShareInstance did not return Region and Zone for instance {instance}.": (
        "DescribeCompShareInstance 未返回实例 {instance} 的 Region 和 Zone。"
    ),
    "Disk {disk} was not found.": "未找到云盘 {disk}。",
    "DescribeCompshareDisk did not return a known location for disk {disk}.": (
        "DescribeCompshareDisk 未返回云盘 {disk} 的有效地域信息。"
    ),
    "Zone is required for this request.": "本次请求必须明确指定 Zone。",
    "--region and --zone must be provided together.": "--region 和 --zone 必须同时指定。",
    "--zone requires --region.": "指定 --zone 时必须同时指定 --region。",
    "--region and --zone are required for platform images.": (
        "查询平台镜像必须指定 --region 和 --zone。"
    ),
    "--region is required for image source {source}.": ("镜像来源 {source} 必须指定 --region。"),
    "--region and --zone are required for image source {source}.": (
        "镜像来源 {source} 必须同时指定 --region 和 --zone。"
    ),
    "--region is required when no instance IDs are provided.": (
        "未提供实例 ID 时必须指定 --region。"
    ),
    "Instances span multiple regions; query each region separately.": (
        "实例分布在多个地域，请按地域分别查询。"
    ),
    "--region and --zone are required for non-interactive create.": (
        "非交互创建必须指定 --region 和 --zone。"
    ),
    "Image {image} was not found.": "未找到镜像 {image}。",
    "Add a community image group to favorites.": "收藏社区镜像组。",
    "Remove a community image group from favorites.": "取消收藏社区镜像组。",
    "Favorited image group {group}": "已收藏镜像组 {group}",
    "Unfavorited image group {group}": "已取消收藏镜像组 {group}",
    "No project was returned by GetProjectList; pass --project-id explicitly.": (
        "GetProjectList 未返回项目，请显式指定 --project-id。"
    ),
    (
        "JSON mode cannot start the interactive wizard; pass --gpu, --count, --cpu, "
        "--memory, --image, --region, and --zone."
    ): (
        "JSON 模式不会启动交互向导，请指定 --gpu、--count、--cpu、--memory、--image、"
        "--region 和 --zone。"
    ),
    "JSON mode cannot prompt for credentials; pass --public-key and --private-key.": (
        "JSON 模式不能交互读取凭证；请传入 --public-key 和 --private-key。"
    ),
    "Option --profile requires a value.": "选项 --profile 需要一个值。",
    "Option --profile may only be specified once.": "选项 --profile 只能指定一次。",
    (
        "No inventory is available for the selected GPU, CPU, memory, image, billing, "
        "and disk combination."
    ): ("所选 GPU、CPU、内存、镜像、计费方式和磁盘组合当前无库存。"),
    "Stop instance": "停止实例",
    "Reboot instance": "重启实例",
    "Permanently delete instance": "永久删除实例",
    "Permanently delete instance and attached data disks": "永久删除实例及其数据盘",
    "Reset instance password": "重置实例密码",
    "Reinstall instance; all system disk data will be lost": "重装实例，系统盘数据将全部丢失",
    "Resize instance": "调整实例规格",
    "Change instance billing type": "变更实例计费方式",
    "Renamed {instance}": "已重命名实例 {instance}",
    "Specify a compute target or both --disk and --disk-size.": (
        "请指定计算规格，或同时指定 --disk 和 --disk-size。"
    ),
    "Compute resizing and disk resizing must be separate operations.": (
        "计算规格调整和磁盘扩容必须分开执行。"
    ),
    "Compute resizing requires --cpu, --memory, and --gpu together.": (
        "调整计算规格时必须同时指定 --cpu、--memory 和 --gpu。"
    ),
    "Specify at least one of --cpu, --memory, or --gpu.": (
        "至少指定 --cpu、--memory 或 --gpu 中的一项。"
    ),
    "Specify at least one --http or --tcp port.": "至少指定一个 --http 或 --tcp 端口。",
    "Replace port mappings for {instance}?": "替换实例 {instance} 的端口映射？",
    "Updated port mappings": "已更新端口映射",
    "Scheduled shutdown must be at least five minutes from now.": (
        "定时关机时间必须至少晚于当前时间 5 分钟。"
    ),
    "Scheduled shutdown": "已设置定时关机",
    "Shutdown schedule": "定时关机计划",
    "Extended scheduled shutdown": "已延后定时关机",
    "Scheduled": "已设置",
    "Not scheduled": "未设置",
    "The API returned an invalid scheduled shutdown time: {value}.": (
        "API 返回了无效的定时关机时间：{value}。"
    ),
    "Instance {instance} has no scheduled shutdown; use `compshare instance schedule set`.": (
        "实例 {instance} 没有定时关机计划；请使用 `compshare instance schedule set`。"
    ),
    "The scheduled shutdown for {instance} has already expired; use "
    "`compshare instance schedule set`.": (
        "实例 {instance} 的定时关机计划已过期；请使用 `compshare instance schedule set`。"
    ),
    "Scheduled shutdown verification failed: expected {expected}, got {actual}.": (
        "定时关机校验失败：预期 {expected}，实际 {actual}。"
    ),
    "Cancel scheduled shutdown for {instance}?": "取消实例 {instance} 的定时关机？",
    "Cancelled shutdown": "已取消定时关机",
    "Environment variables": "环境变量",
    "Profile file": "配置文件",
    "Profile and environment": "配置文件和环境变量",
    "Incomplete credentials": "凭证不完整",
    "Not configured": "未配置",
    "Instance {instance} has no SSH login command.": "实例 {instance} 没有可用的 SSH 登录命令。",
    "The instance SSH login command is invalid.": "实例的 SSH 登录命令无效。",
    "SSH password automation requires compshare-ssh-askpass; reinstall compshare-cli.": (
        "自动填写 SSH 密码需要 compshare-ssh-askpass；请重新安装 compshare-cli。"
    ),
    "Unable to run {executable}: {detail}": "无法运行 {executable}：{detail}",
    "Password hidden; rerun with --show-sensitive to display it.": (
        "密码已隐藏；如需显示，请使用 --show-sensitive 重新运行。"
    ),
    "Automatic password entry is unavailable in this terminal; continuing with standard SSH.": (
        "当前终端无法自动填写密码；将继续使用标准 SSH 连接。"
    ),
    "Automatic password entry is unavailable; continuing with standard SCP.": (
        "无法自动填写密码；将继续使用标准 SCP。"
    ),
    "Local path {path} does not exist.": "本地路径 {path} 不存在。",
    "The instance SSH login command cannot be used for SCP.": (
        "实例的 SSH 登录命令无法转换为 SCP 命令。"
    ),
    "Platform image search supports only one --tag.": "平台镜像查询只支持一个 --tag。",
    "Image source {source} does not support: {options}": "镜像来源 {source} 不支持：{options}",
    "Image source {source} cannot be queried by ID.": "镜像来源 {source} 不支持按 ID 查询。",
    "Create custom image {name} from instance {instance}?": (
        "从实例 {instance} 创建自制镜像 {name}？"
    ),
    "Creating image {name}": "正在创建镜像 {name}",
    "Specify at least one field to update.": "至少指定一个要更新的字段。",
    "Updated image {image}": "已更新镜像 {image}",
    "Permanently delete custom image {image}?": "永久删除自制镜像 {image}？",
    "Deleted image {image}": "已删除镜像 {image}",
    "Shared image {image}": "已共享镜像 {image}",
    "Unshared image {image}": "已取消共享镜像 {image}",
    "Remove {count} share(s) from image {image}?": "从镜像 {image} 移除 {count} 个共享账户？",
    "Publish image {image} as community version {version}?": (
        "将镜像 {image} 发布为社区版本 {version}？"
    ),
    "Published image {image}": "已发布镜像 {image}",
    "Favorited image {image}": "已收藏镜像 {image}",
    "Unfavorited image {image}": "已取消收藏镜像 {image}",
    "Create {size} disk {name} and attach it to {instance}?": (
        "创建 {size} 云盘 {name} 并挂载到 {instance}？"
    ),
    "Created and attached disk {name}": "已创建并挂载云盘 {name}",
    "Attached {disk} to {instance}": "已将云盘 {disk} 挂载到 {instance}",
    "Detach disk {disk} from {instance}? Ensure it is unmounted first.": (
        "从 {instance} 卸载云盘 {disk}？请先在操作系统内卸载文件系统。"
    ),
    "Detached disk {disk}": "已卸载云盘 {disk}",
    "Resize disk {disk} to {size}? Disks cannot be shrunk.": (
        "将云盘 {disk} 扩容到 {size}？云盘不能缩容。"
    ),
    "Resized disk {disk}": "已扩容云盘 {disk}",
    "Permanently delete disk {disk} and all its data?": "永久删除云盘 {disk} 及其全部数据？",
    "Deleted disk {disk}": "已删除云盘 {disk}",
    "Attached US3 to {instance}": "已将 US3 挂载到 {instance}",
    "Resource is still detaching; retrying ({attempt}/{total})...": (
        "资源仍在卸载，正在重试（{attempt}/{total}）……"
    ),
    "The disk is still detaching. Wait a moment and retry.": "云盘仍在卸载，请稍后重试。",
    "Confirm that US3 is enabled for the selected region and account.": (
        "请确认所选地域和账户已开通 US3。"
    ),
    "This production endpoint currently rejects its action; use instance show or the console.": (
        "生产环境的该接口当前拒绝请求，请使用 instance show 或控制台。"
    ),
    "PRICE": "价格",
    "ACTION": "操作",
    "REQUEST": "请求",
    "SSH": "SSH",
    "Waiting for image {image}: {state}": "正在等待镜像 {image}：{state}",
    "Image creation failed: {status}": "镜像创建失败：{status}",
    "Timed out after {timeout}s while waiting for image {image}.": (
        "等待镜像 {image} 超过 {timeout} 秒。"
    ),
    "Return all results.": "返回全部结果。",
    "Instance IDs.": "一个或多个实例 ID。",
    "Start one or more instances.": "启动一个或多个实例。",
    "Stop one or more instances.": "停止一个或多个实例。",
    "Reboot one or more instances.": "重启一个或多个实例。",
    "Permanently delete one or more instances.": "永久删除一个或多个实例。",
    "Wait for instances to reach a state.": "等待实例进入指定状态。",
    "Target instance state.": "目标实例状态。",
    "Maximum total quoted price in CNY.": "允许的最高总报价，单位为人民币元。",
    "The API did not return a price, so --max-price cannot be enforced.": (
        "API 未返回价格，无法执行 --max-price 价格保护。"
    ),
    "Quoted price {price} CNY exceeds --max-price {maximum} CNY; no instance was created.": (
        "报价 {price} 元超过 --max-price 限制 {maximum} 元，未创建实例。"
    ),
    "Invalid amount: {value}. Example: 1000.50": "无效金额：{value}。示例：1000.50",
    "Amount must be positive and use at most two decimal places.": (
        "金额必须大于 0，且最多保留两位小数。"
    ),
    "Manage teams, members, quotas and billing.": "管理团队、成员、额度和账单。",
    "Manage team invitations.": "管理团队邀请。",
    "Manage team members.": "管理团队成员。",
    "Manage team member quotas.": "管理团队成员额度。",
    "Inspect and export team billing.": "查询和导出团队账单。",
    "List teams created by the current account.": "列出当前账户创建的团队。",
    "List teams joined by the current account.": "列出当前账户加入的团队。",
    "Show team details and members.": "显示团队详情和成员。",
    "Create a team.": "创建团队。",
    "Update a team name or description.": "更新团队名称或简介。",
    "Permanently delete an empty team.": "永久删除空团队。",
    "List team invitations received by the current account.": "列出当前账户收到的团队邀请。",
    "Invite users to a team.": "邀请用户加入团队。",
    "Accept a team invitation.": "接受团队邀请。",
    "Reject a team invitation.": "拒绝团队邀请。",
    "Cancel a pending team invitation.": "取消待处理的团队邀请。",
    "List members of a team.": "列出团队成员。",
    "Update a team member remark.": "更新团队成员备注。",
    "Grant quota to team members.": "向团队成员分配额度。",
    "Reclaim quota from team members.": "回收团队成员额度。",
    "List a team member's orders.": "列出团队成员订单。",
    "Show a team member's order summary.": "显示团队成员订单汇总。",
    "List and summarize a team member's unpaid orders.": "列出并汇总团队成员未支付订单。",
    "List product types used by a team member.": "列出团队成员使用的产品类型。",
    "Export team orders to a CSV file.": "将团队订单导出为 CSV 文件。",
    "List team operation logs.": "列出团队操作日志。",
    "Diagnose the CLI configuration and environment.": "诊断 CLI 配置和运行环境。",
    "Team ID.": "团队 ID。",
    "Team name.": "团队名称。",
    "Team description.": "团队简介。",
    "New team name.": "新的团队名称。",
    "New team description.": "新的团队简介。",
    "Filter by membership status.": "按成员关系状态筛选。",
    "User IDs, optionally USER_ID:REMARK.": "用户企业 ID，可使用 USER_ID:备注。",
    "User company ID.": "用户企业 ID。",
    "Member remark.": "成员备注。",
    "Virtual member IDs.": "一个或多个成员虚拟账户 ID。",
    "Virtual member ID.": "成员虚拟账户 ID。",
    "Amount in CNY.": "金额，单位为人民币元。",
    "Start time or past duration.": "开始时间，或 7d 这样的过去时长。",
    "End time.": "结束时间。",
    "Billing type; repeatable.": "计费类型，可重复指定。",
    "Order state; repeatable.": "订单状态，可重复指定。",
    "Resource ID; repeatable.": "资源 ID，可重复指定。",
    "Order sort field.": "订单排序字段。",
    "Operation type; repeatable.": "操作类型，可重复指定。",
    "Status; repeatable.": "状态，可重复指定。",
    "Destination CSV file.": "目标 CSV 文件。",
    "Virtual member ID; 0 means all.": "成员虚拟账户 ID，0 表示全部成员。",
    "Overwrite the destination file.": "覆盖已存在的目标文件。",
    "Create team": "创建团队",
    "Created team {name}": "已创建团队 {name}",
    "Updated team {team}": "已更新团队 {team}",
    "Permanently delete team": "永久删除团队",
    "Deleted team {team}": "已删除团队 {team}",
    "Sent team invitations": "已发送团队邀请",
    "Updated team invitation": "已更新团队邀请",
    "Invalid user {value}; use USER_ID or USER_ID:REMARK.": (
        "无效用户 {value}，请使用 USER_ID 或 USER_ID:备注。"
    ),
    "At most 100 users can be invited at once.": "单次最多邀请 100 名用户。",
    "Destination already exists: {path}. Use --force to overwrite.": (
        "目标文件已存在：{path}。使用 --force 覆盖。"
    ),
    "Unable to write file {path}: {error}": "无法写入文件 {path}：{error}",
    "Team details": "团队详情",
    "Billing summary": "账单汇总",
    "Unpaid summary": "未支付订单汇总",
    "Export completed": "导出完成",
    "Submitting remote job {job_id}...": "正在提交远程任务 {job_id}…",
    "Submitted remote job {job_id}": "已提交远程任务 {job_id}",
    "Remote job {job_id} already exists": "远程任务 {job_id} 已存在",
    "Remote job {job_id} returned no status.": "远程任务 {job_id} 未返回状态。",
    "Remote job {job_id} command failed: {detail}": "远程任务 {job_id} 操作失败：{detail}",
    "Unable to parse the remote job response: {detail}": "无法解析远程任务响应：{detail}",
    "Remote job {job_id} logs ({state})": "远程任务 {job_id} 日志（{state}）",
    "--stream must be all, stdout, or stderr.": "--stream 必须是 all、stdout 或 stderr。",
    "--state must be one of: {states}.": "--state 必须是以下值之一：{states}。",
    "JSON mode does not support --follow; poll logs with byte offsets instead.": (
        "JSON 模式不支持 --follow；请使用字节偏移轮询日志。"
    ),
    "Job ID must be 1-64 letters, numbers, dots, underscores, or hyphens, "
    "and must start with a letter or number.": (
        "任务 ID 长度必须为 1–64，只能包含字母、数字、点、下划线或连字符，且必须以字母或数字开头。"
    ),
    "Duration must use a positive integer followed by s, m, h, d, or w.": (
        "时长必须是正整数加 s、m、h、d 或 w 单位。"
    ),
    "A remote command is required after --.": "必须在 -- 后提供远程命令。",
    "--tail must be positive.": "--tail 必须为正数。",
    "--stdout-offset cannot be negative.": "--stdout-offset 不能为负数。",
    "--stderr-offset cannot be negative.": "--stderr-offset 不能为负数。",
    "--limit must be positive.": "--limit 必须为正数。",
    "Wait timeout and polling interval must be positive.": "等待超时和轮询间隔必须为正数。",
    "Prune duration must be positive.": "清理时长必须为正数。",
    "Cancel remote job {job_id} on {instance}?": "取消实例 {instance} 上的远程任务 {job_id}？",
    "Cancellation requested for remote job {job_id}": "已请求取消远程任务 {job_id}",
    "Remove terminal remote jobs older than {duration} from {instance}?": (
        "清理实例 {instance} 上结束时间超过 {duration} 的远程任务？"
    ),
    "Removed {count} remote jobs": "已清理 {count} 个远程任务",
    "Remote job": "远程任务",
    "Starting": "启动中",
    "Running": "运行中",
    "Cancelling": "取消中",
    "Cancelled": "已取消",
    "Interrupted": "已中断",
    "JOB ID": "任务 ID",
    "PID": "PID",
    "EXIT CODE": "退出码",
    "CREATED TIME": "创建时间",
    "STARTED TIME": "开始时间",
    "FINISHED TIME": "结束时间",
    "CWD": "工作目录",
    "COMMAND": "命令",
    "WAIT TIMED OUT": "等待超时",
    "Version {version}; Python 3.9 or newer is required.": (
        "版本 {version}；要求 Python 3.9 或更高版本。"
    ),
    "Credential profile loaded": "凭证配置加载成功",
    "Unknown error": "未知错误",
    "Config {path}: file {file_mode}, directory {directory_mode}": (
        "配置 {path}：文件权限 {file_mode}，目录权限 {directory_mode}"
    ),
    "Config {path}: Windows ACLs apply; POSIX permission check skipped.": (
        "配置 {path}：由 Windows ACL 管理访问权限，已跳过 POSIX 权限位检查"
    ),
    "Using environment credentials": "正在使用环境变量凭证",
    "Config file does not exist: {path}": "配置文件不存在：{path}",
    "Connected; {count} availability zones returned.": "连接成功，返回 {count} 个可用区。",
    "Skipped because credentials are unavailable": "凭证不可用，已跳过",
    "not installed": "未安装",
    "not installed; remote access commands may be unavailable": ("未安装，远程访问命令可能不可用"),
    "Succeeded": "成功",
    "Success": "成功",
    "Warning": "警告",
    "Failed": "失败",
    "Some instance operations failed.": "部分实例操作失败。",
    "Some team invitations failed.": "部分团队邀请失败。",
    "Some team quota updates failed.": "部分团队额度操作失败。",
    "One or more diagnostic checks failed.": "一个或多个诊断检查失败。",
    "TEAM ID": "团队 ID",
    "MEMBERS": "成员数",
    "USER ID": "用户企业 ID",
    "MEMBER ID": "成员 ID",
    "REMARK": "备注",
    "QUOTA": "已分配额度",
    "AVAILABLE": "可用额度",
    "ORDER": "订单",
    "AMOUNT": "金额",
    "PAID": "实付",
    "RESOURCE": "资源",
    "FREE": "免费额度",
    "COUPON": "优惠券",
    "FAILED": "失败项",
    "PRODUCT": "产品",
    "CHECK": "检查项",
    "DETAIL": "详情",
}


def normalize_language(value: str) -> str:
    normalized = value.strip().lower().replace("_", "-")
    if normalized in {"zh", "zh-cn", "cn"}:
        return "zh"
    if normalized in {"en", "en-us", "en-gb"}:
        return "en"
    raise UsageError("Language must be zh or en.")


def configured_language() -> str:
    value = os.environ.get("COMPSHARE_LANG")
    if value is None:
        try:
            value = ConfigStore().load_language()
        except ConfigError:
            value = None
    return normalize_language(value or DEFAULT_LANGUAGE)


def tr(message: str, **values: object) -> str:
    """Translate a user-facing string and interpolate named values."""
    template = ZH_TRANSLATIONS.get(message, message) if configured_language() == "zh" else message
    return template.format(**values)


def localize_command(command: click.Command, language: str) -> click.Command:
    if language == "en":
        return command

    def translate(value: str) -> str:
        return ZH_TRANSLATIONS.get(value, value)

    if command.help:
        command.help = translate(command.help)
    if command.short_help:
        command.short_help = translate(command.short_help)
    for parameter in command.params:
        help_text = getattr(parameter, "help", None)
        if help_text:
            parameter.help = translate(help_text)
    original_help_option = command.get_help_option

    def localized_help_option(context: click.Context) -> click.Option:
        option = original_help_option(context)
        if option is not None:
            option.help = "显示帮助并退出。"
        return option

    command.get_help_option = localized_help_option  # type: ignore[method-assign]
    children = getattr(command, "commands", None)
    if children is not None:
        for child in children.values():
            localize_command(child, language)
    return command
